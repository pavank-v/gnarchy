<b><span size="large">Version 13.3</span></b>  (2025-09-12)

- Add GNOME 49 Support

<b><span size="large">Version 13.2</span></b>  (2025-08-13)

- Resolve issue causing duplicate wallpapers in the slideshow queue.
- Fix extension crash triggered by special characters in image filenames.